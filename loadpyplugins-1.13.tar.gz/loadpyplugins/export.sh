PROFILE=''

# check if bash or zsh
if [[ $SHELL  == *"zsh" ]]
then 
	PROFILE="$HOME/.zprofile"
else
	PROFILE="$HOME/.profile"
fi

# append trigger command
echo '

# Load python plugins
( nohup loadpyplugins > /dev/null 2>&1 & )' >> $PROFILE

